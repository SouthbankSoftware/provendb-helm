#!/bin/sh

a="Error: failed to init collection \`_provendb_versions\`: (NamespaceExists) a collection \'provendb._provendb_versions\' already exists"
PROVENDB_DB="provendb"
if [[ "$a" == *"Error: failed to init collection "*"(NamespaceExists) a collection "*"already exists"* ]]; then
echo "koustubh"
else
echo "gaikwad"
fi
